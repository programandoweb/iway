<?php

namespace Mpdf\Tag;

class Progress extends Meter
{

}
